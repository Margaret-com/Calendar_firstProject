const params = new URLSearchParams(window.location.search)
let date = params.get('date') || new Date().toISOString().split('T')[0] // Get date from URL or use today's date
const daySpan = document.getElementById('to-do-list')
const saveBtn = document.getElementById('add')
const body = document.querySelector('body')
const button = document.getElementById('modeButton')
const textArea = document.querySelector('textarea')

let storedItems = localStorage.getItem('items')
let itemsArray = []

if (localStorage.getItem('theme')) {
  body.className += localStorage.getItem('theme')
}

button.addEventListener('click', () => {
  if (localStorage.getItem('theme') === 'dark') {
    localStorage.removeItem('theme')
    body.className = ' '
  } else {
    localStorage.setItem('theme', 'dark')
    body.className = 'dark'
  }
})

//Function to add a task to the UI
function addTask(task) {
  textArea.value = task.text
  daySpan.textContent = `Day: ${task.date}`
}

function loadTasksForDate(selectedDate) {
  textArea.value = ''
  daySpan.textContent = `Day: ${selectedDate}`
  const notesForDate = itemsArray.filter((task) => task.date === selectedDate)
  if (notesForDate.length > 0) {
    textArea.value = notesForDate[0].text
  }
}

try {
  itemsArray = storedItems ? JSON.parse(storedItems) : []
  if (!Array.isArray(itemsArray)) {
    itemsArray = []
  }
} catch (error) {
  console.error('Failed to parse items from localStorage:', error)
  itemsArray = []
}

loadTasksForDate(date)

//Save button functionality
saveBtn.addEventListener('click', () => {
  if (textArea.value.trim() === '') return

  const task = {
    date: date, // Use URL date or current date
    text: textArea.value.trim()
  }

  itemsArray = itemsArray.filter((item) => item.date !== date)

  itemsArray.push(task)
  localStorage.setItem('items', JSON.stringify(itemsArray))

  const updateEvent = new CustomEvent('noteUpdated', { detail: itemsArray })
  window.dispatchEvent(updateEvent)

  addTask(task)
})

// Handle popstate for date navigation
window.addEventListener('popstate', () => {
  date = params.get('date') || new Date().toISOString().split('T')[0]
  loadTasksForDate(date)
})
