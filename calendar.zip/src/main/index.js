import { app, shell, BrowserWindow, ipcMain, dialog } from 'electron'
import { join } from 'path'
import fs from 'fs'
import { electronApp, optimizer, is } from '@electron-toolkit/utils'
import icon from '../../resources/icon.png?asset'

let noteWindow

function createWindow() {
  const mainWindow = new BrowserWindow({
    width: 700,
    height: 700,
    show: false,
    ...(process.platform === 'linux' ? { icon } : {}),
    webPreferences: {
      preload: join(__dirname, '../preload/index.js'),
      sandbox: false
    }
  })

  mainWindow.on('ready-to-show', () => {
    mainWindow.show()
  })

  mainWindow.webContents.setWindowOpenHandler((details) => {
    shell.openExternal(details.url)
    return { action: 'deny' }
  })

  if (is.dev && process.env['ELECTRON_RENDERER_URL']) {
    mainWindow.loadURL(process.env['ELECTRON_RENDERER_URL'])
  } else {
    mainWindow.loadFile(join(__dirname, '../renderer/index.html'))
  }
}

app.whenReady().then(() => {
  electronApp.setAppUserModelId('com.electron')

  app.on('browser-window-created', (_, window) => {
    optimizer.watchWindowShortcuts(window)
  })

  ipcMain.handle('saveBackup', async (event, data) => {
    // Open dialog window to save file
    const { filePath } = await dialog.showSaveDialog({
      filters: [{ name: 'JSON Files', extensions: ['json'] }]
    })
    // If a path exists, we write the data to the file
    if (filePath) {
      fs.writeFileSync(filePath, JSON.stringify(data, null, 2))
    }
  })

  //Creating a notes window with the date selected by the user
  ipcMain.on('create-window', (event, options) => {
    noteWindow = new BrowserWindow({ ...options })
    const query = {
      date: options.selectedDate
    }
    noteWindow.loadFile(join(__dirname, '../renderer/note.html'), { query })
    if (is.dev && process.env['ELECTRON_RENDERER_URL']) {
      noteWindow.loadURL(
        `${process.env['ELECTRON_RENDERER_URL']}/note.html?date=${encodeURIComponent(options.selectedDate)}`
      )
    } else {
      noteWindow.loadFile(join(__dirname, '../renderer/note.html'), {
        query: { date: options.selectedDate }
      })
    }

    // Send the date to the window note.html
    noteWindow.webContents.on('did-finish-load', () => {
      const selectedDate = options.selectedDate
      noteWindow.webContents.send('date-load', selectedDate)
    })
  })

  ipcMain.handle('loadBackup', async () => {
    try {
      // Open file selection dialog
      const { canceled, filePaths } = await dialog.showOpenDialog({
        properties: ['openFile'],
        filters: [{ name: 'JSON Files', extensions: ['json'] }]
      })

      if (canceled || filePaths.length === 0) return null

      // If a file is selected, we read the data from the JSON file
      const data = fs.readFileSync(filePaths[0])
      return JSON.parse(data) //The data is returned in case of success
    } catch (error) {
      console.error('Error loading backup: ', error)
      return null
    }
  })

  createWindow()

  app.on('activate', function () {
    if (BrowserWindow.getAllWindows().length === 0) createWindow()
  })
})

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') {
    app.quit()
  }
})
